# 🔔 LinkedIn HR Job Alert Bot

Automatically scrapes LinkedIn for new **Human Resources** jobs and sends you a beautiful HTML email digest every **10 hours**.

---

## 📁 Files

| File | Purpose |
|------|---------|
| `job_alert_bot.py` | **Local runner** — runs continuously on your machine |
| `job_alert_bot_ci.py` | **CI runner** — single-run version for GitHub Actions |
| `.github/workflows/job_alert.yml` | GitHub Actions schedule (every 10 hrs) |
| `requirements.txt` | Python dependencies |
| `seen_jobs.json` | Auto-created; tracks jobs already sent |

---

## 🚀 Option A: Run Locally (always-on machine / server)

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Set up Gmail App Password
1. Go to **myaccount.google.com → Security → 2-Step Verification** (enable it)
2. Then go to **App passwords** → create one for "Mail"
3. Copy the 16-character password

### 3. Edit `job_alert_bot.py`
```python
CONFIG = {
    "sender_email":    "your_gmail@gmail.com",
    "sender_password": "xxxx xxxx xxxx xxxx",   # App Password (no spaces needed)
    "recipient_email": "where_to_send@email.com",
    "keywords":        "Human Resources",
    "location":        "Bengaluru",              # Change as needed
    ...
}
```

### 4. Run
```bash
python job_alert_bot.py
```

The bot loops forever, checking every 10 hours and emailing only **new** jobs it hasn't seen before.

---

## ☁️ Option B: GitHub Actions (free, no server needed) — RECOMMENDED

### 1. Push this folder to a GitHub repo (can be private)

### 2. Add Secrets
Go to **Settings → Secrets → Actions → New repository secret** and add:

| Secret Name | Value |
|-------------|-------|
| `SENDER_EMAIL` | your Gmail address |
| `SENDER_PASSWORD` | your Gmail App Password |
| `RECIPIENT_EMAIL` | email to receive alerts |

Optional secrets:
| `JOB_KEYWORDS` | default: `Human Resources` |
| `JOB_LOCATION` | default: `India` |

### 3. Enable Actions
Go to the **Actions** tab in your repo and enable workflows.

### 4. The workflow runs at `00:00`, `10:00`, `20:00` UTC automatically.
You can also click **Run workflow** manually anytime.

> ⚠️ **Note**: The free GitHub Actions tier gives 2,000 minutes/month — this bot uses ~1 min per run × 3 runs/day = ~90 min/month. Well within limits.

---

## 📧 Sample Email

The email shows:
- Job Title (clickable → LinkedIn)
- Company Name
- Location
- Date Posted
- "View Job" button

---

## ⚙️ Customization

| Setting | How to change |
|---------|--------------|
| Search keywords | Change `keywords` in CONFIG |
| Location | Change `location` (e.g. "Bengaluru", "Remote", "Mumbai") |
| Job type | Set `job_type`: `"F"` = Full-time, `"P"` = Part-time, `"C"` = Contract |
| Frequency | Change `interval_hours` (local) or edit cron in `.github/workflows/job_alert.yml` |
| Max jobs per email | Change `max_jobs` |

---

## 🛠️ Troubleshooting

- **No jobs found**: LinkedIn may have changed its HTML. Try opening the search URL in a browser.
- **Auth error**: Make sure you're using a Gmail **App Password**, not your regular Gmail password.
- **Empty emails**: All jobs were already seen. Delete `seen_jobs.json` to reset.

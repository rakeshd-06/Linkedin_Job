"""
job_alert_bot_ci.py — single-run version for GitHub Actions / CI schedulers.
Reads credentials from environment variables instead of hardcoded config.
"""

import smtplib
import json
import os
import hashlib
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import requests
from bs4 import BeautifulSoup

CONFIG = {
    "sender_email": os.environ["SENDER_EMAIL"],
    "sender_password": os.environ["SENDER_PASSWORD"],
    "recipient_email": os.environ["RECIPIENT_EMAIL"],
    "keywords": os.environ.get("JOB_KEYWORDS", "Human Resources"),
    "location": os.environ.get("JOB_LOCATION", "India"),
    "max_jobs": int(os.environ.get("MAX_JOBS", "20")),
    "seen_jobs_file": "seen_jobs.json",
}

LINKEDIN_SEARCH_URL = (
    "https://www.linkedin.com/jobs/search/"
    "?keywords={keywords}&location={location}&f_TPR=r36000&sortBy=DD"
)
HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "en-US,en;q=0.9",
}


def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def scrape_jobs():
    url = LINKEDIN_SEARCH_URL.format(
        keywords=requests.utils.quote(CONFIG["keywords"]),
        location=requests.utils.quote(CONFIG["location"]),
    )
    print(f"Fetching: {url}")
    try:
        resp = requests.get(url, headers=HEADERS, timeout=15)
        resp.raise_for_status()
    except requests.RequestException as e:
        print(f"[ERROR] {e}")
        return []

    soup = BeautifulSoup(resp.text, "html.parser")
    job_cards = soup.find_all("div", class_="base-card")
    jobs = []
    for card in job_cards[: CONFIG["max_jobs"]]:
        try:
            title = (card.find("h3", class_="base-search-card__title") or {}).get_text(strip=True) or "N/A"
            company = (card.find("h4", class_="base-search-card__subtitle") or {}).get_text(strip=True) or "N/A"
            location = (card.find("span", class_="job-search-card__location") or {}).get_text(strip=True) or "N/A"
            time_el = card.find("time")
            posted = time_el.get("datetime", "N/A") if time_el else "N/A"
            link_el = card.find("a", class_="base-card__full-link")
            link = (link_el.get("href", "#") if link_el else "#").split("?")[0]
            job_id = hashlib.md5(f"{title}{company}{link}".encode()).hexdigest()
            jobs.append({"id": job_id, "title": title, "company": company,
                         "location": location, "posted": posted, "link": link})
        except Exception:
            continue
    print(f"Found {len(jobs)} jobs.")
    return jobs


def load_seen():
    if os.path.exists(CONFIG["seen_jobs_file"]):
        with open(CONFIG["seen_jobs_file"]) as f:
            return set(json.load(f))
    return set()


def save_seen(seen):
    with open(CONFIG["seen_jobs_file"], "w") as f:
        json.dump(list(seen), f)


def build_html(jobs):
    run_time = datetime.now().strftime("%d %b %Y, %I:%M %p")
    rows = ""
    for i, job in enumerate(jobs):
        bg = "#f9f9f9" if i % 2 == 0 else "#ffffff"
        rows += f"""<tr style="background:{bg};">
          <td style="padding:12px 16px;font-weight:600;"><a href="{job['link']}" style="color:#0a66c2;text-decoration:none;">{job['title']}</a></td>
          <td style="padding:12px 16px;color:#444;">{job['company']}</td>
          <td style="padding:12px 16px;color:#666;">{job['location']}</td>
          <td style="padding:12px 16px;color:#888;font-size:13px;">{job['posted']}</td>
          <td style="padding:12px 16px;"><a href="{job['link']}" style="background:#0a66c2;color:#fff;padding:6px 14px;border-radius:4px;text-decoration:none;font-size:13px;">View</a></td>
        </tr>"""
    return f"""<!DOCTYPE html><html><head><meta charset="UTF-8">
    <style>body{{font-family:-apple-system,sans-serif;background:#f0f2f5;margin:0}}
    .wrap{{max-width:900px;margin:24px auto;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.08)}}
    .hdr{{background:#0a66c2;color:#fff;padding:28px 32px}}.hdr h1{{margin:0 0 4px;font-size:22px}}
    table{{width:100%;border-collapse:collapse}}th{{text-align:left;padding:12px 16px;background:#f0f2f5;color:#555;font-size:13px;font-weight:600;text-transform:uppercase;letter-spacing:.5px}}
    .ftr{{padding:20px 32px;background:#f8f8f8;color:#888;font-size:12px;text-align:center;border-top:1px solid #eee}}</style></head>
    <body><div class="wrap"><div class="hdr"><h1>🔔 LinkedIn HR Job Alerts</h1>
    <p style="margin:4px 0 0;opacity:.85">{len(jobs)} new role{'s' if len(jobs)!=1 else ''} · {run_time}</p></div>
    <table><thead><tr><th>Role</th><th>Company</th><th>Location</th><th>Posted</th><th></th></tr></thead>
    <tbody>{rows}</tbody></table>
    <div class="ftr">Search: <b>{CONFIG['keywords']}</b> · Location: <b>{CONFIG['location']}</b></div>
    </div></body></html>"""


def send_email(jobs):
    msg = MIMEMultipart("alternative")
    msg["Subject"] = f"[LinkedIn] {len(jobs)} New HR Job{'s' if len(jobs)!=1 else ''} · {datetime.now().strftime('%d %b, %I:%M %p')}"
    msg["From"] = CONFIG["sender_email"]
    msg["To"] = CONFIG["recipient_email"]
    msg.attach(MIMEText(build_html(jobs), "html"))
    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as s:
        s.login(CONFIG["sender_email"], CONFIG["sender_password"])
        s.sendmail(CONFIG["sender_email"], CONFIG["recipient_email"], msg.as_string())
    print(f"✅ Email sent to {CONFIG['recipient_email']}")


if __name__ == "__main__":
    seen = load_seen()
    jobs = scrape_jobs()
    new_jobs = [j for j in jobs if j["id"] not in seen]
    print(f"{len(new_jobs)} new job(s) after dedup.")
    if new_jobs:
        send_email(new_jobs)
        seen.update(j["id"] for j in new_jobs)
        save_seen(seen)
    else:
        print("No new jobs to report.")

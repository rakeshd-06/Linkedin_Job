"""
LinkedIn HR Job Alert Bot
Scrapes LinkedIn for new HR jobs and sends an email digest every 10 hours.
"""

import smtplib
import json
import os
import time
import hashlib
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import requests
from bs4 import BeautifulSoup

# ─────────────────────────────────────────────
# CONFIGURATION — edit these before running
# ─────────────────────────────────────────────
CONFIG = {
    "sender_email": "your_gmail@gmail.com",       # Gmail you send FROM
    "sender_password": "your_app_password_here",  # Gmail App Password (not your login password)
    "recipient_email": "your_email@example.com",  # Where to receive alerts

    # Job search settings
    "keywords": "Human Resources",                # LinkedIn search keyword
    "location": "India",                          # Location filter (e.g. "Bengaluru", "India", "Remote")
    "job_type": "",                               # "" = all | "F" = full-time | "P" = part-time | "C" = contract
    "max_jobs": 20,                               # Max jobs per email

    # Scheduling
    "interval_hours": 10,                         # How often to run (hours)

    # State file to track already-seen jobs (avoids duplicate alerts)
    "seen_jobs_file": "seen_jobs.json",
}

LINKEDIN_SEARCH_URL = (
    "https://www.linkedin.com/jobs/search/"
    "?keywords={keywords}"
    "&location={location}"
    "&f_TPR=r36000"    # Posted in last 10 hours
    "&sortBy=DD"       # Sort by date descending
)

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "en-US,en;q=0.9",
}


# ─────────────────────────────────────────────
# SCRAPER
# ─────────────────────────────────────────────
def build_search_url():
    url = LINKEDIN_SEARCH_URL.format(
        keywords=requests.utils.quote(CONFIG["keywords"]),
        location=requests.utils.quote(CONFIG["location"]),
    )
    if CONFIG["job_type"]:
        url += f"&f_JT={CONFIG['job_type']}"
    return url


def scrape_jobs():
    url = build_search_url()
    print(f"[{now()}] Fetching jobs from: {url}")

    try:
        resp = requests.get(url, headers=HEADERS, timeout=15)
        resp.raise_for_status()
    except requests.RequestException as e:
        print(f"[ERROR] Failed to fetch LinkedIn: {e}")
        return []

    soup = BeautifulSoup(resp.text, "html.parser")
    job_cards = soup.find_all("div", class_="base-card")

    jobs = []
    for card in job_cards[: CONFIG["max_jobs"]]:
        try:
            title_el = card.find("h3", class_="base-search-card__title")
            company_el = card.find("h4", class_="base-search-card__subtitle")
            location_el = card.find("span", class_="job-search-card__location")
            time_el = card.find("time")
            link_el = card.find("a", class_="base-card__full-link")

            title = title_el.get_text(strip=True) if title_el else "N/A"
            company = company_el.get_text(strip=True) if company_el else "N/A"
            location = location_el.get_text(strip=True) if location_el else "N/A"
            posted = time_el.get("datetime", "N/A") if time_el else "N/A"
            link = link_el.get("href", "#") if link_el else "#"
            # Clean tracking params from URL
            link = link.split("?")[0] if "?" in link else link

            job_id = hashlib.md5(f"{title}{company}{link}".encode()).hexdigest()

            jobs.append({
                "id": job_id,
                "title": title,
                "company": company,
                "location": location,
                "posted": posted,
                "link": link,
            })
        except Exception as e:
            print(f"[WARN] Skipped a card: {e}")
            continue

    print(f"[{now()}] Found {len(jobs)} job(s) on LinkedIn.")
    return jobs


# ─────────────────────────────────────────────
# STATE — track seen jobs to avoid duplicates
# ─────────────────────────────────────────────
def load_seen_jobs():
    path = CONFIG["seen_jobs_file"]
    if os.path.exists(path):
        with open(path, "r") as f:
            return set(json.load(f))
    return set()


def save_seen_jobs(seen):
    with open(CONFIG["seen_jobs_file"], "w") as f:
        json.dump(list(seen), f)


def filter_new_jobs(jobs, seen):
    return [j for j in jobs if j["id"] not in seen]


# ─────────────────────────────────────────────
# EMAIL
# ─────────────────────────────────────────────
def build_email_html(jobs):
    run_time = datetime.now().strftime("%d %b %Y, %I:%M %p")
    rows = ""
    for i, job in enumerate(jobs):
        bg = "#f9f9f9" if i % 2 == 0 else "#ffffff"
        rows += f"""
        <tr style="background:{bg};">
          <td style="padding:12px 16px; font-weight:600; color:#0a66c2;">
            <a href="{job['link']}" style="color:#0a66c2; text-decoration:none;">{job['title']}</a>
          </td>
          <td style="padding:12px 16px; color:#444;">{job['company']}</td>
          <td style="padding:12px 16px; color:#666;">{job['location']}</td>
          <td style="padding:12px 16px; color:#888; font-size:13px;">{job['posted']}</td>
          <td style="padding:12px 16px;">
            <a href="{job['link']}" style="
              background:#0a66c2; color:#fff; padding:6px 14px;
              border-radius:4px; text-decoration:none; font-size:13px; white-space:nowrap;">
              View Job
            </a>
          </td>
        </tr>"""

    return f"""
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; margin:0; background:#f0f2f5; }}
        .container {{ max-width:900px; margin:24px auto; background:#fff; border-radius:8px; overflow:hidden; box-shadow:0 2px 8px rgba(0,0,0,.08); }}
        .header {{ background:#0a66c2; color:#fff; padding:28px 32px; }}
        .header h1 {{ margin:0 0 4px; font-size:22px; }}
        .header p {{ margin:0; opacity:.85; font-size:14px; }}
        .badge {{ display:inline-block; background:rgba(255,255,255,.25); padding:3px 10px; border-radius:12px; font-size:13px; margin-top:8px; }}
        table {{ width:100%; border-collapse:collapse; }}
        th {{ text-align:left; padding:12px 16px; background:#f0f2f5; color:#555; font-size:13px; font-weight:600; text-transform:uppercase; letter-spacing:.5px; }}
        .footer {{ padding:20px 32px; background:#f8f8f8; color:#888; font-size:12px; text-align:center; border-top:1px solid #eee; }}
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>🔔 LinkedIn HR Job Alerts</h1>
          <p>New Human Resources jobs matching your preferences</p>
          <span class="badge">{len(jobs)} new job{'s' if len(jobs) != 1 else ''} · {run_time}</span>
        </div>
        <table>
          <thead>
            <tr>
              <th>Role</th><th>Company</th><th>Location</th><th>Posted</th><th></th>
            </tr>
          </thead>
          <tbody>{rows}</tbody>
        </table>
        <div class="footer">
          You're receiving this because you set up the LinkedIn HR Job Alert Bot.<br>
          Search: <strong>{CONFIG['keywords']}</strong> · Location: <strong>{CONFIG['location']}</strong>
        </div>
      </div>
    </body>
    </html>"""


def send_email(jobs):
    subject = f"[LinkedIn Jobs] {len(jobs)} New HR Role{'s' if len(jobs) != 1 else ''} · {datetime.now().strftime('%d %b, %I:%M %p')}"
    html_body = build_email_html(jobs)

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = CONFIG["sender_email"]
    msg["To"] = CONFIG["recipient_email"]
    msg.attach(MIMEText(html_body, "html"))

    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
            server.login(CONFIG["sender_email"], CONFIG["sender_password"])
            server.sendmail(CONFIG["sender_email"], CONFIG["recipient_email"], msg.as_string())
        print(f"[{now()}] ✅ Email sent to {CONFIG['recipient_email']} with {len(jobs)} jobs.")
    except smtplib.SMTPAuthenticationError:
        print("[ERROR] Gmail authentication failed. Check your App Password.")
    except Exception as e:
        print(f"[ERROR] Failed to send email: {e}")


# ─────────────────────────────────────────────
# MAIN LOOP
# ─────────────────────────────────────────────
def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def run_once():
    print(f"\n{'='*55}")
    print(f"[{now()}] Starting LinkedIn HR Job Alert check...")
    print(f"{'='*55}")

    seen = load_seen_jobs()
    jobs = scrape_jobs()

    if not jobs:
        print(f"[{now()}] No jobs found this cycle.")
        return

    new_jobs = filter_new_jobs(jobs, seen)
    print(f"[{now()}] {len(new_jobs)} new job(s) (not seen before).")

    if new_jobs:
        send_email(new_jobs)
        seen.update(j["id"] for j in new_jobs)
        save_seen_jobs(seen)
    else:
        print(f"[{now()}] All jobs already notified. No email sent.")


def main():
    print("LinkedIn HR Job Alert Bot started.")
    print(f"Running every {CONFIG['interval_hours']} hours.")
    print("Press Ctrl+C to stop.\n")

    while True:
        run_once()
        sleep_secs = CONFIG["interval_hours"] * 3600
        next_run = datetime.fromtimestamp(time.time() + sleep_secs).strftime("%d %b %Y, %I:%M %p")
        print(f"[{now()}] Next check at: {next_run}")
        time.sleep(sleep_secs)


if __name__ == "__main__":
    main()
